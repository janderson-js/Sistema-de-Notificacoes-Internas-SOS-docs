// ============================================================
// Renderização da tabela de funcionários e dos KPIs relacionados
// (online, total). Também atualiza o estado compartilhado com a
// lista mais recente, que o employee-picker.js usa pra busca.
// ============================================================

import { escapeHtml, formatTime } from "./utils.js";
import { setCurrentEmployees } from "./state.js";

export function renderEmployees(employees) {
  setCurrentEmployees(employees);

  const tbody = document.getElementById("employeeTableBody");
  document.getElementById("employeeCountBadge").textContent = employees.length;

  const online = employees.filter((e) => e.status === "online").length;
  document.getElementById("kpiOnline").textContent = online;
  document.getElementById("kpiTotal").textContent = employees.length;

  if (!employees.length) {
    tbody.innerHTML = `<tr><td colspan="3" class="text-center text-secondary py-4">Nenhum funcionário cadastrado</td></tr>`;
    return;
  }

  tbody.innerHTML = employees
    .map(
      (e) => `
    <tr>
      <td class="ps-3 fw-semibold">${escapeHtml(e.name || "Sem nome")}</td>
      <td><span class="dot ${e.status === "online" ? "dot-online" : "dot-offline"}"></span>${e.status === "online" ? "Online" : "Offline"}</td>
      <td class="pe-3 text-secondary small">${formatTime(e.lastSeen)}</td>
    </tr>
  `
    )
    .join("");
}
